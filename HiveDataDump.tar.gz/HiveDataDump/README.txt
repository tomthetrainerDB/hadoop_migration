Greetings Data Importers..

This archive contains data that was exported from hive. 

Your task is to import into spark sql. 

The end goal will be to have a table named for each directory, containing the data held within each directory. 

In order to gather the proper information from hive the output of "show create table" was also collected. 

These commands were used. 

hive -e "show create table world_population_orc_format" > /orc/create_table_statement.sql;
hive -e "show create table world_population_hive_format" > /hive/create_table_statement.sql;
hive -e "show create world_population_parquet_format" > /parquet/create_table_statement.sql;


The all data files were also copied over, for the purpose of this lab that is just one file per table, "0000_0"


Hive Version Used
root@642d16538ea2:/opt# hive --version
Hive 2.3.2
Git git://stakiar-MBP.local/Users/stakiar/Desktop/scratch-space/apache-hive -r 857a9fd8ad725a53bd95c1b2d6612f9b1155f44d
Compiled by stakiar on Thu Nov 9 09:11:39 PST 2017
From source with checksum dc38920061a4eb32c4d15ebd5429ac8a

